<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Legislation and Guidance</title>
    <link rel="stylesheet" type="text/css" 
        href="css/design.css?<?php echo time(); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script src="https://unpkg.com/scrollreveal"></script>
</head>
<body>
    <header>
        <?php include 'menubar.php'; ?>
    </header>

    <section>
        <div id="google_translate_element"></div>

            
        <div class="infoone">
                <img src="images/photos/22.jpg" class="scrollimg">
                <div class="infotext" id="txtinfo">
                    <h2>Data Protection Laws</h2>
                    <p>The protection of personal data is a critical aspect of social media use, especially for teens. Legislation like the General Data Protection Regulation (GDPR) in Europe and the California Consumer Privacy Act (CCPA) in the United States provides clear rules on how online platforms must handle users' personal data. These laws give individuals greater control over their data, ensuring that companies must seek explicit consent before collecting or sharing personal information. Understanding these regulations empowers teens and parents to make informed decisions about what data to share online.</p>
                    
                </div>
            </div>

             <div class="sec-01">
                <div class="homecontainer">
                    <!-- <h2 class="hometitle">How to stay safe online</h2> -->
                        <div class="homecontent">
                           
                            <div class="infotextbox">
                                <h3>Children’s Online Privacy Protection Act</h3>
                                <p>The Children’s Online Privacy Protection Act (COPPA) is a U.S. federal law designed to protect the privacy of children under 13. It requires social media platforms and websites to obtain parental consent before collecting any personal information from minors. This law is particularly important for parents of younger teens who may be exploring social media for the first time. Knowing the protections that COPPA provides helps parents ensure that their children’s online activities are secure and compliant with the law.</p>
                            </div>
                            <div class="homeimg">
                                <img src="images/photos/30.jpg">
                            </div>
                        </div>
                </div>
                </div>

                <div class="sec-02" id="sec-02">
                    <div class="homecontainer">
                            <div class="homecontent">
                            <div class="homeimg" id="img1">
                                <img src="images/photos/31.jpg">
                            </div>
                            <div class="sectextbox" id="txt">
                                <h4 class="sectextboxes">Best Practices for Social Media Use</h4>
                                <p>In addition to legal frameworks, several organizations provide best practice guidance for safe social media use. The Family Online Safety Institute (FOSI) offers comprehensive resources on how to protect young users from online risks. Best practices include setting strong passwords, adjusting privacy settings, and being aware of online scams or suspicious links. Following these guidelines can significantly reduce the chances of exposure to harmful content or identity theft.</p>
                            </div>
                           
                        </div>
                    </div>
                </div>

                <div class="sec-02" id="sec-04">
                    <div class="homecontainer">
                            <div class="homecontent">
                            
                            <div class="sectextbox" id="ctxt">
                                <h4 class="sectextboxes">Cyberbullying Legislation</h4>
                                <p>Cyberbullying is a growing concern among teens on social media, and several countries have enacted specific laws to address this issue. In the UK, the Malicious Communications Act makes it illegal to send threatening or offensive messages, while in the U.S., many states have passed anti-cyberbullying laws that allow victims to seek legal action against their harassers. Understanding these laws empowers victims of cyberbullying to report incidents and seek justice, helping create a safer online environment.</p>
                            </div>
                            <div class="pimg" id="imgg">
                                <img src="images/photos/35.jpg">
                            </div>
                        </div>
                    </div>
                </div>
                </div>

                <div class="sec-01">
                    <div class="homecontainer">
                            <div class="homecontent">
                                <div class="homeimg">
                                    <img src="images/photos/34.webp">
                                </div>
                                <div class="textbox" id="atxt">
                                    <h3>Guidelines for Responsible Content Sharing</h3>
                                    <p>Online platforms often provide their own community guidelines to ensure responsible content sharing. These guidelines prohibit the sharing of harmful or inappropriate content, including violence, hate speech, and explicit material. Adhering to these rules not only helps keep users safe but also promotes a positive and respectful online community. Social media users, especially teens, should familiarize themselves with these guidelines to ensure that their content aligns with platform standards and avoids penalties or bans.</p>
                                </div>
                            </div>
                            <div class="iconsmedia">
                                <a href="#" class="icons"><i class="fa-brands fa-facebook-f"></i></a>
                                <a href="#" class="icons"><i class="fa-brands fa-youtube"></i></a>
                                <a href="#" class="icons"><i class="fa-brands fa-whatsapp"></i></a>
                                <a href="#" class="icons"><i class="fa-brands fa-instagram"></i></a>
                        </div>
                    </div>
                </div>


    </section>
    <script> 

        ScrollReveal({ 
            reset: true,
            distance: '60px',
            duration: 2500,
            delay: 400,
        });

        ScrollReveal().reveal('.scrollimg, .sec-02 .secinfotextbox, .infotextbox, .hometextbox, .hometitle, .homesectitle', { delay: 500, origin: 'left' });
        ScrollReveal().reveal('.sec-01 .homeimg, .sec-02 .homeimg', { delay: 600, origin: 'bottom' });
        ScrollReveal().reveal('.sectextbox, .infotext', { delay: 700, origin: 'right' });
        ScrollReveal().reveal('.iconsmedia i', { delay: 500, origin: 'bottom', interval: 200 });
        ScrollReveal().reveal('.sec-03 .homeimg', { delay: 500, origin: 'top' });
        ScrollReveal().reveal('.mediainfo li', { delay: 500, origin: 'left', interval: 200});

        ScrollReveal().reveal('.scrollimg, .hometitle, .homesectitle', { delay: 500, origin: 'left' });
        ScrollReveal().reveal('.sec-01 .homeimg, .sec-02 .pimg, .sectextbox', { delay: 600, origin: 'bottom' });
        ScrollReveal().reveal('.textbox, .hometext', { delay: 700, origin: 'right' });
        ScrollReveal().reveal('.iconsmedia i', { delay: 500, origin: 'bottom', interval: 200 });
        ScrollReveal().reveal('.sec-02 .homeimg, .sec-03 .homeimg', { delay: 500, origin: 'top' });

    </script>
    <script type="text/javascript">
        
        function googleTranslateElementInit() {

        new google.translate.TranslateElement({pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element');

    }

    </script>
    <script type="text/javascript" src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>

    <footer>
        <?php 
            
            include 'footer.php'; 
        
        ?>

            <script type="text/javascript">
                document.getElementById('you_are_here').innerHTML="<b>Legislation and Guidance Page</b>";
            </script>
    </footer>



</body>
</html>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" 
        href="css/design.css?<?php echo time(); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>SMC Website</title>
</head>
<body>
    <div class="logout">
		<span onclick="openNav()">&#9776; <b>Admin Panel</b></span>
        <button><a href='logout.php'><i class="fa fa-sign-out"></i></a></button>
    
			<div id="mySidenavbar" class="sidenavbar">
				<a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
				<a href="home.php">Home</a>
				<a href="userlist.php">User List</a>
				<a href="showcontact.php">View Messages</a>
				<a href="entryapps.php">Entry Apps</a>
				<a href="information.php">Information</a>
				<a href="popularapps.php">Most Popular Social Media Apps</a>
				<a href="parentscanhelp.php">How Parents Can Help</a>
				<a href="livestreaming.php">Livestreaming</a>
				<a href="legiandgui.php">Legislation and Guidance</a>
				<a href="contact.php">Contact</a>
			</div>


			<script>
				function openNav() {
				document.getElementById("mySidenavbar").style.width = "250px";
				}

				function closeNav() {
				document.getElementById("mySidenavbar").style.width = "0";
				}
			</script>
	</div>

</body>
</html>
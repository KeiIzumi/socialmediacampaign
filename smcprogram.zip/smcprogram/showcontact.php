<?php 
   session_start(); 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" 
        href="css/design.css?<?php echo time(); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>Show Contact</title>
</head>
<body>
        <?php 
            include 'adminpanel.php';
        ?>
    <div class="body">
    
        <?php

            include("dbconnection.php");

            if(isset($_SESSION['role']))
            {
                if($_SESSION['role']=="admin")
                {

                    $sql ="select * from contact";

                    $result =mysqli_query($connection,$sql);

                    $num_rows =mysqli_num_rows($result);

                    for($i=0;$i<$num_rows;$i++)
                    {
                        $record = mysqli_fetch_assoc($result);

                        echo "<div class='design'><p>Email</p>"
                            . $record['email']."<p>Message</p>"
                            .$record['message'].
                            "</div>";
                    }
                }
            }

            else{
                echo "<script>
                        alert('Adminstrator only!');
                    </script>";
            }

        ?>
    </div>
    <footer>
        <?php 
            
            include 'footer.php'; 
        
        ?>

            <script type="text/javascript">
                document.getElementById('you_are_here').innerHTML="<b>Show Contact Page</b>";
            </script>
    </footer>
</body>
</html>
<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Logout</title>
</head>
<body>
	<h1>Logout</h1>

	<?php
		session_destroy(); //destroy all sessions 

		unset($_SESSION['role']); //role session only

		echo "<script>
				alert('You are Successfully Logout!!');
				window.location.href='home.php';
			</script>";
		
	?>



</body>
</html>
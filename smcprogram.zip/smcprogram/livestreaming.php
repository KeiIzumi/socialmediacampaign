<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Livestreaming</title>
    <link rel="stylesheet" type="text/css" 
        href="css/design.css?<?php echo time(); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script src="https://unpkg.com/scrollreveal"></script>
</head>
<body>
    <header>
        <?php include 'menubar.php'; ?>
    </header>

    <section>
        <div id="google_translate_element"></div>

        <div class="sec-01">
                <div class="homecontainer">
                    <!-- <h2 class="hometitle">How to stay safe online</h2> -->
                        <div class="homecontent">
                           
                            <div class="infotextbox">
                                <h3>Understanding Livestreaming</h3>
                                <p>Livestreaming allows users to broadcast video content in real time to a global audience. Popular platforms such as YouTube, Twitch, and Instagram have made it easier than ever for teens to share their experiences live. While livestreaming can be a fun way to connect with friends and followers, it also comes with risks such as sharing personal information or encountering inappropriate content. The Stay Safe Online Campaign aims to educate teens on how to stream safely by understanding the tools and privacy controls available to them.</p>
                            </div>
                            <div class="homeimg">
                                <img src="images/photos/24.jpg">
                            </div>
                        </div>
                        <div class="iconsmedia">
                            <a href="#" class="icons"><i class="fa-brands fa-facebook-f"></i></a>
                            <a href="#" class="icons"><i class="fa-brands fa-youtube"></i></a>
                            <a href="#" class="icons"><i class="fa-brands fa-whatsapp"></i></a>
                            <a href="#" class="icons"><i class="fa-brands fa-instagram"></i></a>
                        </div>
                </div>
                </div>
                <div class="sec-02">
                    <div class="homecontainer">
                            <div class="homecontent">
                            <div class="homeimg" id="img">
                                <img src="images/photos/23.jpg">
                            </div>
                            <div class="sectextbox" id="wtxt">
                                <h4 class="sectextboxes">Setting Boundaries for Safety</h4>
                                <p>One of the most important aspects of livestreaming is setting boundaries. Teens should be aware of what personal details they’re sharing and avoid revealing sensitive information such as their location, school, or home address. Encouraging teens to create a safe streaming environment involves using privacy settings to control who can watch, interact, and comment on their livestreams. By maintaining these boundaries, they can enjoy the experience without compromising their safety.</p>
                            </div>
                           
                        </div>
                    </div>
                </div>
        
                <div class="sec-02" id="sec-02">
                    <div class="homecontainer">
                            <div class="homecontent">
                           
                            <div class="secinfotextbox" id="txt">
                                <h4 class="sectextboxes">Recognizing Inappropriate Content</h4>
                                <p>When livestreaming, teens may encounter or accidentally broadcast inappropriate content. It’s essential to educate them about the consequences of sharing harmful or offensive material. The Stay Safe Online Campaign provides guidelines on recognizing inappropriate behavior and reporting issues to platform moderators. Encouraging teens to maintain a positive and respectful environment not only keeps them safe but also protects their viewers.</p>
                            </div>
                            <div class="homeimg" id="img1">
                                <img src="images/photos/27.jpg">
                            </div>
                        </div>
                    </div>
                </div>

                <div class="infoone">
                <img src="images/photos/28.jpg" class="scrollimg">
                <div class="infotext" id="txtinfo">
                    <h2>Moderating Viewer Interaction</h2>
                    <p>Managing interactions during a livestream is crucial for safety. Teens should use moderation tools to filter out inappropriate comments and block unwanted users. Platforms often offer tools such as comment filters, muting, and reporting features that can help maintain a safe environment for both the streamer and their audience. Teaching teens how to manage these interactions helps create a respectful and enjoyable livestreaming experience.</p>
                    
                </div>
            </div>

            <div class="sec-01">
                <div class="homecontainer">
                    <!-- <h2 class="hometitle">How to stay safe online</h2> -->
                        <div class="homecontent">
                           
                            <div class="infotextbox">
                                <h3>Parental Involvement and Support</h3>
                                <p>Parents play a vital role in helping teens navigate the world of livestreaming. By discussing the potential risks and regularly reviewing their teen’s livestreams, parents can ensure that safety guidelines are followed. Encouraging teens to be open about their streaming activities fosters trust and helps parents offer guidance when needed. The Stay Safe Online Campaign advocates for parent involvement to ensure livestreaming remains a safe and positive experience for teens.</p>
                            </div>
                            <div class="homeimg">
                                <img src="images/photos/29.jpg">
                            </div>
                        </div>
                        <div class="iconsmedia">
                            <a href="#" class="icons"><i class="fa-brands fa-facebook-f"></i></a>
                            <a href="#" class="icons"><i class="fa-brands fa-youtube"></i></a>
                            <a href="#" class="icons"><i class="fa-brands fa-whatsapp"></i></a>
                            <a href="#" class="icons"><i class="fa-brands fa-instagram"></i></a>
                        </div>
                </div>
                </div>

    </section>

    <script> 

        ScrollReveal({ 
            reset: true,
            distance: '60px',
            duration: 2500,
            delay: 400,
        });

        ScrollReveal().reveal('.scrollimg, .sec-02 .secinfotextbox, .infotextbox, .hometextbox, .hometitle, .homesectitle', { delay: 500, origin: 'left' });
        ScrollReveal().reveal('.sec-01 .homeimg, .sec-02 .homeimg', { delay: 600, origin: 'bottom' });
        ScrollReveal().reveal('.sectextbox, .infotext', { delay: 700, origin: 'right' });
        ScrollReveal().reveal('.iconsmedia i', { delay: 500, origin: 'bottom', interval: 200 });
        ScrollReveal().reveal('.sec-03 .homeimg', { delay: 500, origin: 'top' });
        ScrollReveal().reveal('.mediainfo li', { delay: 500, origin: 'left', interval: 200});

        ScrollReveal().reveal('.scrollimg, .hometitle, .homesectitle', { delay: 500, origin: 'left' });
        ScrollReveal().reveal('.sec-01 .homeimg, .sec-02 .pimg, .sectextbox', { delay: 600, origin: 'bottom' });
        ScrollReveal().reveal('.textbox, .hometext', { delay: 700, origin: 'right' });
        ScrollReveal().reveal('.iconsmedia i', { delay: 500, origin: 'bottom', interval: 200 });
        ScrollReveal().reveal('.sec-02 .homeimg, .sec-03 .homeimg', { delay: 500, origin: 'top' });

</script>
    
    <script type="text/javascript">
        
        function googleTranslateElementInit() {

        new google.translate.TranslateElement({pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element');

    }

    </script>
    <script type="text/javascript" src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>

    <footer>
        <?php 
            
            include 'footer.php'; 
        
        ?>

            <script type="text/javascript">
                document.getElementById('you_are_here').innerHTML="<b>Livestreaming Page</b>";
            </script>
    </footer>




</body>
</html>
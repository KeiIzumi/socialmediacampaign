<?php 
    session_start(); 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" 
        href="css/design.css?<?php echo time(); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>SMC Website</title>
</head>
<body>

    <header id="header"> 
       
            <!-- Logo Image -->
            <div class="logo">
                <img src="images/logo/smclogo.png">
            </div>
            <!-- Navigation Bar -->
            
            <div id="myHomenavbar" class="homenavbar">
            <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
            <nav>
                <ul>
                    <li><a href="home.php">Home</a></li>
                    <li><a href="information.php">Information</a></li>
                    <li><a href="popularapps.php">Most Popular Social Media Apps</a></li>
                    <li class="fld"><a href="#">About</a>
                        <ul class="menu">
                            <li><a href="parentscanhelp.php">How Parents Can Help</a></li>
                            <li><a href="livestreaming.php">Livestreaming</a></li>
                            <li><a href="legiandgui.php">Legislation and Guidance</a></li>
                        </ul>
                    </li>
                    <li><a href="contact.php">Contact</a></li>
                </ul>
            </nav>    
        </div> 
            <!-- Search Icon -->
            <div class="box">
                <input type="search" placeholder="Search...">
                    <a href="#">
                        <i class="fa fa-search"></i>
                    </a>
            </div>
            <!-- Login form -->
                    <div class="login">
                        <input type="checkbox" id="btn">
                        <label for="btn" class="btn-click">
                            <i class="fa-solid fa-user"></i>
                        </label>
                        <button><a href="register.php">Sign Up</a></button>
                        <div class="click" id="cl">
                            <label for="btn" class="close-btn fas fa-times"></label>
                            <div class="text">Login</div>
                                <form action="loginprocess.php" method="post">
                                    <div class="info">
                                        <label>Username</label>
                                        <input type="text" name="username" required>
                                        <i class='fas fa-user-alt username'></i>
                                    </div>
                                    <div class="info">
                                        <label>Password</label>
                                        <input type="password" name="password" id="Showpw">
                                        <i class='fas fa-lock password'></i>
                                    </div>
                                    <div class="show-pw">
                                        <input type="checkbox" id="clchk" onclick="showpassword()">
                                        <label>Show Password</label>
                                    </div>
                                    <script type="text/javascript">
                                        function showpassword() {
                                            var Showpw = document.getElementById('Showpw');
                                            if(Showpw.type == 'password'){
                                                Showpw.type = 'text';
                                            }
                                            else{
                                                Showpw.type = 'password'
                                            }
                                        }
                                    </script>
                                    <div class="login-btn">
                                        <div class="inter"></div>
                                        <input type="submit" name="submit" id="ltr" value="Login">
                                    </div>
                                    <div class="register-lnk">
                                        Don't have an account? <a href="register.php">Sign Up</a>
                                    </div>
                                </form>
                        </div>
                    </div>
                    <span onclick="openNav()">&#9776; </span>
            <script>
				function openNav() {
				document.getElementById("myHomenavbar").style.width = "250px";
				}

				function closeNav() {
				document.getElementById("myHomenavbar").style.width = "0";
				}
			</script>
        </header>

</body>
</html>
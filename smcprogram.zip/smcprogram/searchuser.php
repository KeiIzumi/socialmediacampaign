<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" 
        href="css/design.css?<?php echo time(); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>Seaech User</title>
</head>
<body>
    <div class="searchuser">
        <form action="searchuser_process.php" class="suser" method="post">
            <input type="text" name="keyword" placeholder="Search...">
            <button class="btnsearch">Search</button>
            <!-- <input type="submit" name="submit" placeholder="search"> -->
        </form>
    </div>
</body>
</html>
<?php 
   session_start(); 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" 
        href="css/design.css?<?php echo time(); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>Search User Process</title>
</head>
<body>
    
    <?php
         include 'adminpanel.php';
         include 'dbconnection.php';
         include 'searchuser.php';
    ?>

  <?php
        if(isset($_SESSION['role']))
        {
            if(isset($_SESSION['role'])=="admin")
            {
                $keyword = mysqli_real_escape_string($connection,$_POST['keyword']);
                $sql = "select * from user
                        where firstname LIKE '%$keyword%' OR
                              surname LIKE '%$keyword%' OR
                              email LIKE '%$keyword%' OR
                              country LIKE '%$keyword%' ";

                $result =mysqli_query($connection,$sql);

                $num_rows =mysqli_num_rows($result);

                if($num_rows==0)
                {
                    //not found
                    echo "<script>
                            alert('No user in the list!');
                            window.location.href='userlist.php';
                         </script>";

                }
                else
                {
                    echo "<table border='1'>";
                            echo "<thead>";
                            echo "<tr>
                                    <th>No.</th>
                                    <th>Profile</th>
                                    <th>First Name</th>
                                    <th>Surname</th>
                                    <th>Email</th>
                                    <th>Phone</th>
                                    <th>Country</th>
                                    <th>Actions</th>			
                                </tr>";
                        for($i=0;$i<$num_rows;$i++)
                        {
                            $user = mysqli_fetch_assoc($result); //one row 
                            $user_id = $user['id'];	
                
                            echo "<tr>";
                                echo "<td>".($i+1)."</td>";
                                echo "<td>
                                       <img src='".$user['profile']."' 
                                             width='45px' height='45px'>
                                      </td>";
                                echo "<td>".$user['firstname']."</td>";
                                echo "<td>".$user['surname']."</td>";
                                echo "<td>".$user['email']."</td>";
                                echo "<td>".$user['phone']."</td>";
                                echo "<td>".$user['country']."</td>";
                                echo "<td ><a href='edituser.php?id=$user_id' class='edit-btn'><i class='fas fa-edit'></i></a>
                                          <a href='deleteuser.php?id=$user_id' class='delete-btn'><i class='fas fa-trash'></i></a>
                                      </td>";
                
                            echo "</tr>";
                        } //end for
                    echo "</thead>";
                    echo "</table>";
                }//user found
            }
        }//session

        else
            {
                echo "<script> alert('Administrator only!');</script>";
            }
        

    ?>

    <script type="text/javascript">

        function confirmDelete(user_id){
            if(confirm("Are you sure you want to delete?"))
            {
                window.location.href="deleteUser.php?id="+user_id;
            }else{
                document.getElementById('mydiv').innerHTML="<b><i>Cancel to delete user!</i></b>";
            }
        }
    </script>




</body>
</html>
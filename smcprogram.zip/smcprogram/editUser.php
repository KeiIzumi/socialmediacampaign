<?php session_start();  ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" 
        href="css/design.css?<?php echo time(); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
	<title>Edit User</title>
</head>
<body>
		<?php 
            include 'dbconnection.php';
            include 'adminpanel.php'; 
        ?>
	<div class="section2">
	<?php

	if(isset($_SESSION['role']))
	{
		if($_SESSION['role']=="admin"){


			//edit


			$user_id = $_GET['id'];

			//retrieve role and remark for the user
			$sql = "select * from user where id=$user_id";	

			$result = mysqli_query($connection,$sql);

			$user = mysqli_fetch_assoc($result);
			$firstname = $user['firstname'];
			$role = $user['role'];

			//ask user to edit using FORM
 
		echo "<form action='edit_process.php' class='edit' method='POST'>
				<input type='hidden' name='user_id' value='$user_id'>
				<label>First Name</label>
				<input type='text' name='firstname' value='$firstname'><br>
				<label>Role</label>
				<input type='text' name='role' value='$role'><br>
				<input type='submit' name='submit' value='Edit'>
				<input type='reset' name='reset' value='Clear'>
			</form>";

		}
	}
	else echo "<script>
				alert('Adminstrator only!');
			</script>";

	?>
	</div>
	<footer>
        <?php 
            
            include 'footer.php'; 
        
        ?>

            <script type="text/javascript">
                document.getElementById('you_are_here').innerHTML="<b>Edit User Page</b>";
            </script>
    </footer>
</body>
</html>
<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Login Process</title>
</head>
<body>

	<?php 

		if(isset($_SESSION['login_counter']))
		{
			$counter = $_SESSION['login_counter'];
		}
		else{
			$counter=0;
		}



		include("dbconnection.php"); 

		$username = $_POST['username'];
		$password = $_POST['password'];


		$sql = "select * from user where username='$username'";

		$result = mysqli_query($connection,$sql);

		$num_rows = mysqli_num_rows($result);

		if($num_rows==1){

			$record = mysqli_fetch_assoc($result);
			$hashed_pw = $record['password'];

			if(password_verify($password, $hashed_pw)){
				// echo "Welcome $username<br>";
				if($username=="admin" && $record['role']=="admin"){

					$_SESSION['role']="admin";

					include("userlist.php");

					// echo "<script
				    //    window.location.href='userlist.php';
				    //  </script>";

				}//admin only
				else{
						
					echo "<script>
							window.location.href='home.php';
						</script>";
				}//user only

			}//correct password
			else {
				//echo "Invalid Password! Please try again!";


				$counter++;

				$_SESSION['login_counter']=$counter;
				if($counter==3){
					echo "<script> 
							window.location.href='loginTimer.php';
							</script>";
					setcookie("login_counter","c",Time()+10*600); //10minutes
				}
				else{
					echo "<script>
						alert('Invalid Login! Please try again!');
						window.location.href='home.php';
						</script>";
				}
			} // invalid login

		}
		else{
			//echo "Invalid Username! Please try again!";
			echo "<script>
				       alert('Invalid Username! Please try again!');
				       window.location.href='home.php';
				  </script>";
		}
		

	?>
</body>
</html>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link rel="stylesheet" type="text/css" 
        href="css/design.css?<?php echo time(); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script src="https://unpkg.com/scrollreveal"></script>
   
</head>
<body>
    <header>
        <?php include 'menubar.php'; ?>
    </header>

    <section>
    <div id="google_translate_element"></div>
        <div id="custom_cursor">

        <div class="homepage">

            <div class="homeone">
                <img src="images/photos/5.png" class="scrollimg">
                <div class="hometext">
                    <h2>Welcome to the Stay Safe Online Campaign</h2>
                    <p>Our mission is to empower teenagers and their parents to navigate social media safely by providing essential tips and resources on how to protect personal information and stay secure while using popular social media platforms.</p>
                
                    <div class="linkflex">
                        <div class="flexinfo"><a href="information.php">Read More</a></div>
                        <div class="flexcontact"><a href="Contact.php">Contact Us</a></div>
                    </div>
                </div>
            </div>
            </div>
            <div class="sec-01">
                <div class="homecontainer">
                    <h2 class="hometitle">How to stay safe online</h2>
                        <div class="homecontent">
                            <div class="homeimg">
                                <img src="images/photos/h2.png">
                            </div>
                            <div class="textbox">
                                <h3>Manage Your Privacy Settings</h3>
                                <p>Regularly review the privacy settings on each social media app you use. Adjust them to control who can see your posts, follow you, and message you. For added protection, set your profiles to private.</p>
                            </div>
                        </div>
                        <div class="iconsmedia">
                            <a href="#" class="icons"><i class="fa-brands fa-facebook-f"></i></a>
                            <a href="#" class="icons"><i class="fa-brands fa-youtube"></i></a>
                            <a href="#" class="icons"><i class="fa-brands fa-whatsapp"></i></a>
                            <a href="#" class="icons"><i class="fa-brands fa-instagram"></i></a>
                        
                        <p><b>"The Teen Brain and Social Media"</b><br>The teenage brain is still developing, making it more sensitive to the effects of social media. With increased exposure to likes, comments, and online interactions, teens often face heightened emotional responses and impulsive behaviors. The **Stay Safe Online Campaign** aims to educate teens about these effects, helping them build healthy online habits and making informed decisions about their digital footprint. By understanding how social media impacts their brain, teens can better manage their time online and avoid the risks of excessive usage.</p>
                      
                        </div>
                </div>
                </div>
                <div class="sec-02">
                    <div class="homecontainer">
                            <div class="homecontent">
                            <div class="sectextbox" id="txtx">
                                <h4 class="sectextboxes">Use Strong Passwords and Two-Factor Authentication (2FA)</h4>
                                <p>Always use a unique, strong password for each social media platform and enable two-factor authentication. This adds an extra layer of security by requiring a second form of verification.</p>
                            </div>
                            <div class="homeimg" id="img">
                                <img src="images/photos/h3.jpg">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="sec-02" id="sec-02">
                    <div class="homecontainer">
                            <div class="homecontent">
                            <div class="homeimg" id="img1">
                                <img src="images/photos/h4.jpg">
                            </div>
                            <div class="sectextbox" id="txt">
                                <h4 class="sectextboxes">Limit Location Sharing</h4>
                                <p>Many social media apps have location-sharing features, such as Instagram’s location tags or Snapchat’s Snap Map. Turn off these features unless absolutely necessary to prevent others from tracking your movements.</p>
                            </div>
                           
                        </div>
                    </div>
                </div>




                <div class="sec-01">
                    <div class="homecontainer">
                        <h2 class="hometitle">Most popular social media apps</h2>
                            <div class="homecontent">
                                <div class="homeimg">
                                    <img src="images/photos/h5.avif" alt="">
                                </div>
                                <div class="textbox">
                                    <h3>Facebook</h3>
                                    <p>Facebook offers many ways to connect with friends and family, but younger users should be mindful of its privacy settings. Regularly review your profile visibility and limit what strangers can see.</p>
                                </div>
                            </div>
                            <div class="iconsmedia">
                                <a href="#" class="icons"><i class="fa-brands fa-facebook-f"></i></a>
                                <a href="#" class="icons"><i class="fa-brands fa-youtube"></i></a>
                                <a href="#" class="icons"><i class="fa-brands fa-whatsapp"></i></a>
                                <a href="#" class="icons"><i class="fa-brands fa-instagram"></i></a>
                        </div>
                    </div>
                </div>
                <div class="sec-02">
                    <div class="homecontainer">
                            <div class="homecontent">
                            <div class="sectextbox" id="txtx">
                                <h4 class="sectextboxes">YouTube</h4>
                                <p>A platform for video sharing and streaming, YouTube can be educational and entertaining. But, due to the risk of inappropriate content, it's important to use YouTube’s safety features, like Restricted Mode, to filter out harmful material.</p>
                            </div>
                            <div class="homeimg" id="img">
                                <img src="images/photos/h6.avif">
                            </div>
                        </div>
                    </div>
                </div>

                <div class="sec-01">
                    <div class="homecontainer">
                     
                            <div class="homecontent">
                                <div class="homeimg">
                                    <img src="images/photos/h8.avif">
                                </div>
                                <div class="textbox">
                                    <h3>Instagram</h3>
                                    <p>A photo and video-sharing platform where users can post content, follow friends, and explore a variety of media. However, it’s important to be cautious about privacy settings and avoid sharing too much personal information with the public.</p>
                                </div>
                            </div>
                            <div class="iconsmedia">
                                <a href="#" class="icons"><i class="fa-brands fa-facebook-f"></i></a>
                                <a href="#" class="icons"><i class="fa-brands fa-youtube"></i></a>
                                <a href="#" class="icons"><i class="fa-brands fa-whatsapp"></i></a>
                                <a href="#" class="icons"><i class="fa-brands fa-instagram"></i></a>
                        </div>
                    </div>
                </div>
                <div class="sec-02" id="sec-04">
                    <div class="homecontainer">
                            <div class="homecontent">
                            
                            <div class="sectextbox" id="txt">
                                <h4 class="sectextboxes">WhatsApp</h4>
                                <p>A messaging app owned by Meta that offers encrypted communications. To stay safe, be sure to enable two-step verification and be wary of unsolicited messages or spam links.</p>
                            </div>
                            <div class="homeimg" id="img1">
                                <img src="images/photos/h7.avif">
                            </div>
                        </div>
                    </div>
                </div>
                </div>

                <!-- <div class="sec-03">
                    <div class="homecontainer">
                     
                            <div class="homecontent">
                            <div class="mediainfo">
                                <li><a href="https://www.facebook.com/" target="_blank"><i class="fa-brands fa-facebook-f"></i></a></li>
                                <li><a href="https://x.com/" target="_blank"><i class="fa-brands fa-x-twitter"></i></a></li>
                                <li><a href="https://www.linkedin.com/" target="_blank"><i class="fa-brands fa-linkedin-in"></i></a></li>
                                <li><a href="https://www.instagram.com/" target="_blank"><i class="fa-brands fa-instagram"></i></a></li>
                                <li><a href="https://www.instagram.com/" target="_blank"><i class="fa-brands fa-youtube"></i></a></li>
                            </div>
                            <div class="homeimg">
                                <img src="images/photos/h9.avif">
                            </div>
                        </div>
                    </div>
                </div> -->
    </section>
    
    <script> 

        ScrollReveal({ 
            reset: true,
            distance: '60px',
            duration: 2500,
            delay: 400,
        });

        ScrollReveal().reveal('.scrollimg, .hometitle, .homesectitle', { delay: 500, origin: 'left' });
        ScrollReveal().reveal('.sec-01 .homeimg, .sectextbox', { delay: 600, origin: 'bottom' });
        ScrollReveal().reveal('.textbox, .hometext', { delay: 700, origin: 'right' });
        ScrollReveal().reveal('.iconsmedia i', { delay: 500, origin: 'bottom', interval: 200 });
        ScrollReveal().reveal('.sec-02 .homeimg, .sec-03 .homeimg', { delay: 500, origin: 'top' });
        ScrollReveal().reveal('.mediainfo li', { delay: 500, origin: 'left', interval: 200});

    </script>

        <script type="text/javascript">
        
                function googleTranslateElementInit() {
        
            new google.translate.TranslateElement({pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element');
        
            }
        
        </script>
        <script type="text/javascript" src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>

        <footer>
        <?php 
            
            include 'footer.php'; 
        
        ?>

            <script type="text/javascript">
                document.getElementById('you_are_here').innerHTML="<b>Home Page</b>";
            </script>
    </footer>
</body>
</html>
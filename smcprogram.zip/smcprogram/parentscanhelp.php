<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>How Parents Can Help</title>
    <link rel="stylesheet" type="text/css" 
        href="css/design.css?<?php echo time(); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script src="https://unpkg.com/scrollreveal"></script>
</head>
<body>
    <header>
        <?php include 'menubar.php'; ?>
    </header>

    <section>
        <div id="google_translate_element"></div>

            <div class="infoone">
                <img src="images/photos/18.jpeg" class="scrollimg">
                <div class="infotext" id="ptxt">
                    <h2>Set Clear Boundaries</h2>
                    <p>Parents should establish clear rules and expectations around social media use, including time limits and appropriate content sharing. Openly discuss with your teen the importance of balance between online and offline activities. Setting these boundaries early helps teens understand the potential risks of overuse and encourages them to be more mindful of their online habits.</p>
                    
                </div>
            </div>

             <div class="sec-01">
                <div class="homecontainer">
                    <!-- <h2 class="hometitle">How to stay safe online</h2> -->
                        <div class="homecontent">
                           
                            <div class="infotextbox">
                                <h3>Be Informed About Platforms</h3>
                                <p>Stay informed about the social media platforms your teen uses. Regularly review the privacy settings, safety features, and content policies of these platforms. By knowing how each app operates, you’ll be better equipped to guide your teen through safe usage, helping them make responsible decisions regarding what to post and whom to interact with online.</p>
                            </div>
                            <div class="homeimg">
                                <img src="images/photos/h10.avif">
                            </div>
                        </div>
                </div>
                </div>

                <div class="sec-02" id="sec-02">
                    <div class="homecontainer">
                            <div class="homecontent">
                            <div class="homeimg" id="img1">
                                <img src="images/photos/19.jpg">
                            </div>
                            <div class="sectextbox" id="txt">
                                <h4 class="sectextboxes">Encourage Open Communication</h4>
                                <p>Creating an environment where your teen feels comfortable discussing their online experiences is key. Encourage them to share both positive and negative encounters on social media. By keeping communication channels open, you can provide timely support, address concerns about cyberbullying, or offer advice on how to handle inappropriate content or interactions.</p>
                            </div>
                           
                        </div>
                    </div>
                </div>

                <div class="sec-02" id="sec-04">
                    <div class="homecontainer">
                            <div class="homecontent">
                            
                            <div class="sectextbox" id="ftxt">
                                <h4 class="sectextboxes">Monitor and Guide</h4>
                                <p>While it’s important to respect your teen’s privacy, gently monitoring their social media activity can be beneficial. Use parental controls or apps to oversee their online interactions and ensure they are engaging safely. Regularly review their follower lists, messages, and posts to spot any potential red flags, such as cyberbullying, inappropriate content, or interactions with strangers.</p>
                            </div>
                            <div class="pimg" id="imgg">
                                <img src="images/photos/20.jpg">
                            </div>
                        </div>
                    </div>
                </div>
                </div>

                <div class="sec-01">
                    <div class="homecontainer">
                            <div class="homecontent">
                                <div class="homeimg">
                                    <img src="images/photos/21.jpg">
                                </div>
                                <div class="textbox">
                                    <h3>Model Responsible Behavior</h3>
                                    <p>Teens often learn by observing their parents’ behavior. Demonstrate responsible social media use by managing your own screen time, maintaining privacy, and avoiding oversharing. Modeling these behaviors helps teens understand the importance of self-regulation and the long-term impact of digital footprints, ensuring they adopt healthy online habits.</p>
                                </div>
                            </div>
                            <div class="iconsmedia">
                                <a href="#" class="icons"><i class="fa-brands fa-facebook-f"></i></a>
                                <a href="#" class="icons"><i class="fa-brands fa-youtube"></i></a>
                                <a href="#" class="icons"><i class="fa-brands fa-whatsapp"></i></a>
                                <a href="#" class="icons"><i class="fa-brands fa-instagram"></i></a>
                        </div>
                    </div>
                </div>


    </section>

    <script> 

        ScrollReveal({ 
            reset: true,
            distance: '60px',
            duration: 2500,
            delay: 400,
        });

        ScrollReveal().reveal('.scrollimg, .sec-02 .secinfotextbox, .infotextbox, .hometextbox, .hometitle, .homesectitle', { delay: 500, origin: 'left' });
        ScrollReveal().reveal('.sec-01 .homeimg, .sec-02 .homeimg', { delay: 600, origin: 'bottom' });
        ScrollReveal().reveal('.sectextbox, .infotext', { delay: 700, origin: 'right' });
        ScrollReveal().reveal('.iconsmedia i', { delay: 500, origin: 'bottom', interval: 200 });
        ScrollReveal().reveal('.sec-03 .homeimg', { delay: 500, origin: 'top' });
        ScrollReveal().reveal('.mediainfo li', { delay: 500, origin: 'left', interval: 200});

        ScrollReveal().reveal('.scrollimg, .hometitle, .homesectitle', { delay: 500, origin: 'left' });
        ScrollReveal().reveal('.sec-01 .homeimg, .sec-02 .pimg, .sectextbox', { delay: 600, origin: 'bottom' });
        ScrollReveal().reveal('.textbox, .hometext', { delay: 700, origin: 'right' });
        ScrollReveal().reveal('.iconsmedia i', { delay: 500, origin: 'bottom', interval: 200 });
        ScrollReveal().reveal('.sec-02 .homeimg, .sec-03 .homeimg', { delay: 500, origin: 'top' });

    </script>

    <script type="text/javascript">
        
        function googleTranslateElementInit() {

        new google.translate.TranslateElement({pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element');

    }

    </script>
    <script type="text/javascript" src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>

    <footer>
        <?php 
            
            include 'footer.php'; 
        
        ?>

            <script type="text/javascript">
                document.getElementById('you_are_here').innerHTML="<b>How Parents Can Help Page</b>";
            </script>
    </footer>



</body>
</html>
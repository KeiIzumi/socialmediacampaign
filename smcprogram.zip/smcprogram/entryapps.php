<?php
    include 'dbconnection.php';
    include 'adminpanel.php'; 

    if (isset($_POST['add'])) {
        $app_name = $_POST['app_name'];
        $safety_tip = $_POST['safety_tip'];
        

        $target_dir = "images/photos/"; 
        $target_file = $target_dir . basename($_FILES["image"]["name"]);
        $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
        
   
        $check = getimagesize($_FILES["image"]["tmp_name"]);
        if($check !== false) {
  
            if ($_FILES["image"]["size"] < 5000000) {

                if($imageFileType == "jpg" || $imageFileType == "png" || $imageFileType == "jpeg" || $imageFileType == "gif" || $imageFileType == "avif") {
                    
                    if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
                       
                        $sql = "INSERT INTO popularapps (app_name, safety_tip, image) VALUES ('$app_name', '$safety_tip', '$target_file')";
                        if ($connection->query($sql) === TRUE) {
                            echo "<script>alert('New app added successfully!'); 
                                        window.location.href='entryapps.php';
                                    </script>";
                        } else {
                            echo "Error: " . $sql . "<br>" . $connection->error;
                        }
                    } else {
                        echo "Sorry, there was an error uploading your file.";
                    }
                } else {
                    echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
                }
            } else {
                echo "Sorry, your file is too large.";
            }
        } else {
            echo "File is not an image.";
        }
    }

    if (isset($_POST['update'])) {
        $id = $_POST['id'];
        $app_name = $_POST['app_name'];
        $safety_tip = $_POST['safety_tip'];
        $image = $_POST['image'];

        $sql = "UPDATE popularapps SET app_name='$app_name', safety_tip='$safety_tip', image='$image' WHERE id=$id";

        if ($connection->query($sql) === TRUE) {
            
            echo "<script>alert('App updated successfully!'); 
                </script>";
        } else {
            echo "Error: " . $sql . "<br>" . $connection->error;
        }
    }

    // Delete app
    if (isset($_POST['delete'])) {
        $id = $_POST['id'];

        $sql = "DELETE FROM popularapps WHERE id=$id";

        if ($connection->query($sql) === TRUE) {
            echo "<script>
                    alert('App deleted successfully.');
                </script>";
        } else {
            echo "Error: " . $sql . "<br>" . $connection->error;
        }
    }

    // Fetch all popularapps
    $sql = "SELECT * FROM popularapps";
    $result = $connection->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - Social Media Apps</title>
    <link rel="stylesheet" type="text/css" 
        href="css/design.css?<?php echo time(); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
<section>
    <div class="admin">
        <h2>Add New App</h2>
        <form action="" method="POST" enctype="multipart/form-data">
            <input type="text" name="app_name" placeholder="App Name" required>
            <!-- <textarea name="safety_tip" id="safetytxt" placeholder="Safety Tip" required></textarea> -->
            <input type="text" name="safety_tip" placeholder="Safety Tip" required>
            <input type="file" name="image" id="files" required>
            <button type="submit" name="add">Add App</button>
        </form>
        </div>
    <div class="adminedit">
        <h2>Edit & Delete Social Media Apps</h2>
        <table>
            <thead>
                <tr>
                    <th>App Name</th>
                    <th>Safety Tip</th>
                    <th>Image</th>
                    <th>Edit</th>
                    <th>Delete</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<form action='' method='POST'>";
                        echo "<input type='hidden' name='id' value='" . htmlspecialchars($row['id']) . "'>";
                        echo "<td><input type='text' name='app_name' class='tble' value='" . htmlspecialchars($row['app_name']) . "'></td>";
                        echo "<td><input type='text' name='safety_tip' class='tble' value='" . htmlspecialchars($row['safety_tip']) . "'></td>";
                        echo "<td><input type='text' name='image' class='tble' value='" . htmlspecialchars($row['image']) . "'></td>";
                        echo "<td><button type='submit' name='update'>Update</button></td>";
                        echo "<td><button type='submit' name='delete' id='dele'>Delete</button></td>";
                        echo "</form>";
                        echo "</tr>";
                    }
                }
                ?>
            </tbody>
        </table>
    </div> 
    </section>
    <footer>
        <?php 
            
            include 'footer.php'; 
        
        ?>

            <script type="text/javascript">
                document.getElementById('you_are_here').innerHTML="<b>Entry Page</b>";
            </script>
    </footer>

</body>
</html>

<?php $connection->close(); ?>

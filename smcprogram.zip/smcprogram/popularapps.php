<?php
    include 'dbconnection.php';
    include 'menubar.php'; 

    // Search functionality
    $searchTerm = "";
    if (isset($_GET['search'])) {
        $searchTerm = $_GET['search'];
    }

    // Fetch apps from the database
    $sql = "SELECT * FROM popularapps WHERE app_name LIKE '%$searchTerm%'";
    $result = $connection->query($sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Most Popular Social Media Apps</title>
    <link rel="stylesheet" type="text/css" 
        href="css/design.css?<?php echo time(); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script src="https://unpkg.com/scrollreveal"></script>
</head>
<body>

    <div id="google_translate_element"></div>
    <section class="intro">
        <h2>Most Popular Social Media Apps</h2>
        <p>Search for the latest techniques to stay safe on the most popular social media platforms used by teens.</p>
    </section>

    <section class="search-section">
        <div class="search-container">
            <form action="" id="formfl" method="GET">
                <input type="text" name="search" id="search-bar" placeholder="Search for a social media app..." value="<?php echo htmlspecialchars($searchTerm); ?>">
                <button type="submit">Search</button>
            </form>
        </div>
    </section>

    <section class="apps-info">
        <div class="app-grid">
            <?php
            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    echo "<div class='app-card'>";
                    echo "<img src='" . htmlspecialchars($row['image']) . "' alt='" . htmlspecialchars($row['app_name']) . " logo'>";
                    echo "<h3>" . htmlspecialchars($row['app_name']) . "</h3>";
                    echo "<p>" . htmlspecialchars($row['safety_tip']) . "</p>";
                    echo "</div>";
                }
            } else {
                echo "<p>No apps found. Try searching for something else.</p>";
            }
            ?>
        </div>
    </section>
    <script> 

        ScrollReveal({ 
            reset: true,
            distance: '60px',
            duration: 2500,
            delay: 400,
        });

        ScrollReveal().reveal('.app-grid', { delay: 500, origin: 'bottom', interval: 200 });
        

    </script>
     <script type="text/javascript">
        
        function googleTranslateElementInit() {

        new google.translate.TranslateElement({pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element');

        }

    </script>
<script type="text/javascript" src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
    <footer>
        <?php 
            
            include 'footer.php'; 
        
        ?>

            <script type="text/javascript">
                document.getElementById('you_are_here').innerHTML="<b>Most Popular Social Media Apps Page</b>";
            </script>
    </footer>

</body>
</html>

<?php $connection->close(); ?>

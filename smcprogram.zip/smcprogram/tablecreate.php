<?php

	$host = "localhost";
	$username = "root";
	$password = "";

	$dbname = "smcprogram";

	$connection = mysqli_connect($host,$username,$password,$dbname);

	if($connection)
	    // echo "Database connection established!<br>";

		echo "<script>
				alert('Database connection established!');
			</script>";
	else 
		// echo "Database Connection Failed!<br>";

		echo "<script>
				alert('Database Connection Failed!');
			</script>";

	$sql = "create table if not exists popularapps
			(id int auto_increment primary key, 
			app_name varchar(255), 
			safety_tip text, 						
			image varchar(255))";

	if(mysqli_query($connection,$sql))
		// echo "User Table is created!<br>";
		echo "<script>
				alert('User Table is created!');
			</script>";
	else 
		// echo "Table creation error!<br>";
		echo "<script>
				alert('Table creation error!');
			</script>";

	/*
		$sql = "create table if not exists user
				(id int auto_increment primary key, 
	   			firstname varchar(20), 
	   			surname varchar(20), 
				email varchar(20),
				phone varchar(20),
				username varchar(20),
				dateofbirth date,
				password varchar(30),
				country varchar(20),
				address text,
	   			gender varchar(10),
				profile text,
				role varchar(10)";


		$sql = "create table if not exists contact
	             			(id int auto_increment primary key, 
							firstname varchar(50), 
							surname varchar(50), 						
							email varchar(50),
							message text,							
							remark text)";

	*/



?>
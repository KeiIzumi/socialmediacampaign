<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" 
        href="css/design.css?<?php echo time(); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>Contact</title>
</head>
<body>
    <header>
        <?php 
            include 'dbconnection.php';
            include 'menubar.php'; 
        ?>
    </header>
    <section>
        
        <?php 
            if(isset($_POST['submit']))
            {
    
                $fname = mysqli_real_escape_string($connection,$_POST['fname']);
                $lname = mysqli_real_escape_string($connection,$_POST['lname']);
                $email = $_POST['email'];			
                $phone= $_POST['phone'];
                $message = mysqli_real_escape_string($connection,$_POST['message']);
            
    
                $sql = "insert into contact(firstname,lastname,email,phone,message) 
                            values('$fname','$lname','$email','$phone','$message')";
    
                if(mysqli_query($connection,$sql))
                {
                    
                    echo "<script>
                            alert('Message was sent!');
                            window.location.href='home.php';
                            </script>";
                }
            }
            else
            {
        
        ?>
            <div class="container">
                <h2>Contact Us <p>Feel free to reach out to us! Whether you are prepared to launch a new social media campaign or simply considering your choices, our team is ready to assist you. Complete the form provided below, and we will respond to you at the earliest opportunity.</p></h2>
            </div>
            <div class="mbox">
                <div class="contact form">
                    <h3>Send us a Message</h3>
                    <form action="contact.php" method="post">
                        <div class="fbox">
                            <div class="fb">
                                <div class="input-box">
                                    <span>First Name</span>
                                    <input type="text" name="fname" placeholder="John">
                                </div>
                                <div class="input-box">
                                    <span>Last Name</span>
                                    <input type="text" name="lname" placeholder="Smith">
                                </div>
                            </div>
                            <div class="fb">
                                <div class="input-box">
                                    <span>Email</span>
                                    <input type="email" name="email" placeholder="johnsmith@gmail.com">
                                </div>
                                <div class="input-box">
                                    <span>Mobile</span>
                                    <input type="text" name="phone" placeholder="+95 428 944 327">
                                </div>
                            </div>
                            <div class="fbmessage">
                                <div class="input-box">
                                    <span>Message</span>
                                    <textarea name="message" placeholder="Write your message..."></textarea>
                                </div>
                            </div>
                            <div class="fbmessage" id="pp">
                                <input type="checkbox" id="ppchk" value="I agree">
                                <label>I agree to the</label>
                                    <a href="privacy_policy.php">Privacy Policy</a>
                                
                            </div>
                            <div class="fbmessage">
                                <div class="input-box">
                                    <input type="submit" name="submit" id="str" value="Send">
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                    <div class="contact infor">
                        <h3>Contact Info</h3>
                        <div class="info-box">
                            <div>
                                <span><i class="fa-solid fa-location-dot"></i></span>
                                <p>Yangon, Myanmar</p>
                            </div>
                            <div>
                                <span><i class="fa-solid fa-envelope"></i></span>
                                <a href="#">innumakitoge@gmail.com</a>
                            </div>
                            <div>
                                <span><i class="fa-solid fa-phone"></i></span>
                                <a href="#">+95 254 201 023</a>
                            </div>
                            <ul class="social">
                                <li><a href="https://www.facebook.com/"><i class="fa-brands fa-facebook-f"></i></a></li>
                                <li><a href="https://x.com/"><i class="fa-brands fa-x-twitter"></i></a></li>
                                <li><a href="https://www.linkedin.com/"><i class="fa-brands fa-linkedin-in"></i></a></li>
                                <li><a href="https://www.instagram.com/"><i class="fa-brands fa-instagram"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="contact map">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15279.956624919534!2d96.14509738715817!3d16.777215100000003!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x30c1ededd5ba5db3%3A0x16158806b5877345!2sCampaign%20Weekly!5e0!3m2!1sen!2smm!4v1725485846640!5m2!1sen!2smm" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                    </div>
            </div>
        
    </section>

    <footer>
        <?php }
            
            include 'footer.php'; 
        
        ?>

            <script type="text/javascript">
                document.getElementById('you_are_here').innerHTML="<b>Contact Page</b>";
            </script>
    </footer>

</body>
</html>
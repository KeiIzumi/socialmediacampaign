<?php session_start();  ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Delete User</title>
</head>
<body>
	<h1>Delete User</h1>

	<?php

	if(isset($_SESSION['role']))
	{
		if($_SESSION['role']=="admin"){

			include("dbconnection.php");
			//delete

			$user_id = $_GET['id'];

			$sql = "delete from user where id=$user_id";

			if(mysqli_query($connection, $sql)){
				echo "<script>
						alert('User record is deleted!');
						window.location.href='home.php';
						</script>";
			}
			else echo "Deletion error!<br>";

		}
	}
	else echo "Administrator only!<br>";

	?>

	

</body>
</html>
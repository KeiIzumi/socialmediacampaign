<?php

	$host = "localhost";
	$username = "root";
	$password = "";

	$dbname = "smcprogram";

	$connection = mysqli_connect($host,$username,$password,$dbname);
?>
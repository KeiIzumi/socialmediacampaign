<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" 
        href="css/design.css?<?php echo time(); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <title>Footer</title>
</head>
<body>
    <footer>
        <div class="rows">
                <img src="images/logo/smclogo.png">
            <div class="column">
                <h3>Office</h3>
                <p>Bo Aung Kyaw Road</p>
                <p>Botahtaung Township</p>
                <p>Yangon, Myanmar</p>
                <p>innumakitoge@gmail.com</p>
                <p>+95 254 201 023</p>
            </div>
            
            <ul class="fmenu">
                <h3>Links</h3>
                <li><a href="home.php">Home</a></li>
                <li><a href="information.php">Information</a></li>
                <li><a href="popularapps.php">Most Popular<br>Social Media Apps</a></li>
                <li><a href="contact.php">Contact</a></li>
            </ul>

            <ul class="about-menu">
                <h3>Services</h3>
                <li><a href="parentscanhelp.php">How Parents<br> Can Help</a></li>
                <li><a href="livestreaming.php">Livestreaming</a></li>
                <li><a href="legiandgui.php">Legislation and <br>Guidance</a></li>
            </ul>
            
            <ul class="socialicons">
                <h3>Follow Us</h3>
                <div class="social-flex">
                    <li><a href="https://www.facebook.com/" target="_blank"><i class="fa-brands fa-facebook-f"></i></a></li>
                    <li><a href="https://x.com/" target="_blank"><i class="fa-brands fa-x-twitter"></i></a></li>
                    <li><a href="https://www.linkedin.com/" target="_blank"><i class="fa-brands fa-linkedin-in"></i></a></li>
                    <li><a href="https://www.instagram.com/" target="_blank"><i class="fa-brands fa-instagram"></i></a></li>
                </div>
            </ul>
        </div>
        <hr>
        <div class="flex-contain">
            <h5>&copy;2024 Social Media Campaigns</h5>
            <div class="yrh-img">
                <img src="images/photos/4.png">
                <div id="you_are_here"></div>
            </div>
        </div>
    </footer>
</body>
</html>
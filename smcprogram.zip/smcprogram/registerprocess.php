<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Register Process</title>
</head>
<body>
	<?php  include("dbconnection.php");  ?>


	<?php

		if(isset($_POST['submit'])){
			
			////////////   recaptcha    ////////////////
			if(isset($_POST['g-recaptcha-response'])){
 
				$captcha=$_POST['g-recaptcha-response'];
	   
			}
			  if(!$captcha){
	
				echo "<script>
						alert('Please check the the captcha form');
						window.location.href='register.php';
					</script>";
				exit;
	   
			  }
			  $secretKey = "6LfIs0wqAAAAAI3uxQAUCe9CmLc9FdB952bq6PRe";
			  $ip = $_SERVER['REMOTE_ADDR'];
			  // post request to server
	   
			  $url = 'https://www.google.com/recaptcha/api/siteverify?secret=' . urlencode($secretKey) .  '&response=' . urlencode($captcha);
			  $response = file_get_contents($url);
	   
			  $responseKeys = json_decode($response,true);
			  // should return JSON with success as true
	   
			  if($responseKeys["success"]) {
	   
					  
					$fname = mysqli_real_escape_string($connection,$_POST['fname']);
					$sname = mysqli_real_escape_string($connection,$_POST['sname']);
					$email = $_POST['email'];			
					$phone= $_POST['phone'];
					$username = $_POST['username'];
					$dob = $_POST['dob'];
					$pw = $_POST['pw'];
					$country = $_POST['country'];
					$confirm_pw = $_POST['confirm_pw'];
					$address = mysqli_real_escape_string($connection,$_POST['address']);
					$gender = $_POST['gender'];
					$profile_name = $_FILES['profile']['name'];
					$tmp_name = $_FILES['profile']['tmp_name'];
					$profile_path = "images/pfp/".$username."_".$profile_name;

				if($pw==$confirm_pw){
					//existing username

					$sql_search = "select * from user where username = '$username'";

					$result = mysqli_query($connection,$sql_search);

					$num_rows = mysqli_num_rows($result);

					if($num_rows<1){
						//saving information

						copy($tmp_name,$profile_path);

						$hashed_pw = password_hash($pw, PASSWORD_DEFAULT);

						$sql = "insert into user(firstname, surname, email, phone, username, dateofbirth, password, country, address, gender, profile, role) 
							values('$fname','$sname','$email','$phone','$username','$dob','$hashed_pw','$country','$address','$gender','$profile_path','user')";


						if(mysqli_query($connection,$sql))	
							
								echo "<script>
										alert('Your data is successfully saved!');
										window.location.href='home.php';
										</script>";
						else echo "Error!<br>";	
					}	//not-existing user
					else {
						
						echo "<script>
								alert('Sorry, that username already exits!');
								window.location.href='home.php';
								</script>";
					}
				} //confirm pw
				else {
					
						echo "<script>
							alert('Password don't match. Please try again!');
							window.location.href='register.php';
							</script>";
					}
				}
				else {
	
						echo "<script>
								alert('reCaptcha verification failed');
							</script>";
		
				}

		} //submit 

	?>

</body>
</html>
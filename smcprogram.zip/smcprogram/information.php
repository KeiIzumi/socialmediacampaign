<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Information</title>
    <link rel="stylesheet" type="text/css" 
        href="css/design.css?<?php echo time(); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <script src="https://unpkg.com/scrollreveal"></script>
</head>
<body>
    <header>
        <?php include 'menubar.php'; ?>
    </header>

    <section>
        <div id="google_translate_element"></div>

        <div class="sec-01">
                <div class="homecontainer">
                    <!-- <h2 class="hometitle">How to stay safe online</h2> -->
                        <div class="homecontent">
                           
                            <div class="infotextbox">
                                <h3>Overview of the Campaign</h3>
                                <p>The Stay Safe Online Campaign is dedicated to raising awareness about the risks and challenges teenagers face on social media. With the rapid growth of online platforms, teens are more vulnerable to privacy breaches, cyberbullying, and online predators. This campaign aims to provide parents, educators, and teenagers with the tools, knowledge, and resources to navigate the digital world safely. By promoting responsible social media usage, we encourage healthy online behavior, empowering teens to engage with technology in a secure and protected environment.</p>
                            </div>
                            <div class="homeimg">
                                <img src="images/photos/h9.avif">
                            </div>
                        </div>
                        <div class="iconsmedia">
                            <a href="#" class="icons"><i class="fa-brands fa-facebook-f"></i></a>
                            <a href="#" class="icons"><i class="fa-brands fa-youtube"></i></a>
                            <a href="#" class="icons"><i class="fa-brands fa-whatsapp"></i></a>
                            <a href="#" class="icons"><i class="fa-brands fa-instagram"></i></a>
                        </div>
                </div>
                </div>
                <div class="sec-02">
                    <div class="homecontainer">
                            <div class="homecontent">
                            <div class="homeimg" id="img">
                                <img src="images/photos/13.jpg">
                            </div>
                            <div class="sectextbox" id="sectxts">
                                <h4 class="sectextboxes">Our Mission</h4>
                                <p>Our mission is simple but crucial: to create a safer digital space for teenagers. We strive to educate and empower young users by offering them the skills and resources they need to protect their privacy, maintain their digital footprint, and avoid potential online threats. This campaign promotes awareness of privacy settings, encourages responsible sharing, and addresses the dangers of cyberbullying and inappropriate content. By fostering a culture of mindfulness and safety, we aim to build a generation of tech-savvy individuals who can confidently manage their online presence.</p>
                            </div>
                           
                        </div>
                    </div>
                </div>
        
                <div class="sec-02" id="sec-02">
                    <div class="homecontainer">
                            <div class="homecontent">
                           
                            <div class="secinfotextbox">
                                <h4 class="sectextboxes">Our Vision</h4>
                                <p>Our vision is a world where teenagers can fully enjoy the benefits of social media while staying protected from its potential harms. We believe that through education and digital literacy, young people can become aware of the risks involved and take proactive measures to safeguard their personal information. The Stay Safe Online Campaign envisions a future where teens are empowered to be responsible online citizens who are aware of both the dangers and opportunities of the digital age.</p>
                            </div>
                            <div class="homeimg" id="img1">
                                <img src="images/photos/14.jpeg">
                            </div>
                        </div>
                    </div>
                </div>

                <div class="infoone">
                <img src="images/photos/15.jpg" class="scrollimg">
                <div class="infotext" id="txtinfo">
                    <h2>Focus Areas</h2>
                    <p>The campaign focuses on three key areas: Privacy, Safety, and Digital Well-being. In the area of privacy, we aim to teach teens how to manage their social media settings, control who sees their posts, and understand how data is used by online platforms. Our safety initiatives cover topics such as recognizing and avoiding online predators, responding to cyberbullying, and reporting inappropriate content. Lastly, digital well-being focuses on promoting a balanced relationship with social media by limiting screen time, maintaining mental health, and encouraging offline activities.</p>
                    
                </div>
            </div>

            <div class="sec-01">
                <div class="homecontainer">
                    <!-- <h2 class="hometitle">How to stay safe online</h2> -->
                        <div class="homecontent">
                           
                            <div class="infotextbox">
                                <h3>How to Get Involved</h3>
                                <p>Parents, educators, and community members are all encouraged to participate in the Stay Safe Online Campaign. Whether it’s through attending webinars, accessing our resources, or sharing our materials with others, your involvement makes a difference. Together, we can create a safer online environment for teens by spreading awareness and promoting best practices for social media safety. By participating, you become part of a movement that safeguards the future of our younger generations in the digital world.</p>
                            </div>
                            <div class="homeimg">
                                <img src="images/photos/17.jpg">
                            </div>
                        </div>
                        <div class="iconsmedia">
                            <a href="#" class="icons"><i class="fa-brands fa-facebook-f"></i></a>
                            <a href="#" class="icons"><i class="fa-brands fa-youtube"></i></a>
                            <a href="#" class="icons"><i class="fa-brands fa-whatsapp"></i></a>
                            <a href="#" class="icons"><i class="fa-brands fa-instagram"></i></a>
                        </div>
                </div>
                </div>


    </section>

    <script> 

        ScrollReveal({ 
            reset: true,
            distance: '60px',
            duration: 2500,
            delay: 400,
        });

        ScrollReveal().reveal('.scrollimg, .sec-02 .secinfotextbox, .infotextbox, .hometextbox, .hometitle, .homesectitle', { delay: 500, origin: 'left' });
        ScrollReveal().reveal('.sec-01 .homeimg, .sec-02 .homeimg', { delay: 600, origin: 'bottom' });
        ScrollReveal().reveal('.sectextbox, .infotext', { delay: 700, origin: 'right' });
        ScrollReveal().reveal('.iconsmedia i', { delay: 500, origin: 'bottom', interval: 200 });
        ScrollReveal().reveal('.sec-03 .homeimg', { delay: 500, origin: 'top' });
        ScrollReveal().reveal('.mediainfo li', { delay: 500, origin: 'left', interval: 200});

        ScrollReveal().reveal('.scrollimg, .hometitle, .homesectitle', { delay: 500, origin: 'left' });
        ScrollReveal().reveal('.sec-01 .homeimg, .sectextbox', { delay: 600, origin: 'bottom' });
        ScrollReveal().reveal('.textbox, .hometext', { delay: 700, origin: 'right' });
        ScrollReveal().reveal('.iconsmedia i', { delay: 500, origin: 'bottom', interval: 200 });
        ScrollReveal().reveal('.sec-02 .homeimg, .sec-03 .homeimg', { delay: 500, origin: 'top' });
        
    </script>

    <script type="text/javascript">
        
        function googleTranslateElementInit() {

        new google.translate.TranslateElement({pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element');

    }

    </script>
    <script type="text/javascript" src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>

    <footer>
        <?php 
            
            include 'footer.php'; 
        
        ?>

            <script type="text/javascript">
                document.getElementById('you_are_here').innerHTML="<b>Information Page</b>";
            </script>
    </footer>
</body>
</html>
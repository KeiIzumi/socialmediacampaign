<?php 
   //session_start(); 
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" 
        href="css/design.css?<?php echo time(); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
	<title>User List</title>
</head>
<body>

	<?php include 'adminpanel.php'; ?>

	<!-- <h1>User List</h1> -->

	<div class="section">

	<?php

	if(isset($_SESSION['role']))
	{
		if($_SESSION['role']=="admin"){

		include("dbconnection.php");

		include 'searchuser.php';

		$sql = "select * from user where role='user'"; //all users // where role='user'"; 

		$result = mysqli_query($connection,$sql);

		$num_rows = mysqli_num_rows($result);

		echo "<table border='1'>";
		echo "<thead>";
		echo "<tr>
				<th>No.</th>
				<th>Profile</th>
				<th>First Name</th>
				<th>Surname</th>
				<th>Email</th>
				<th>Phone</th>
                <th>Date of Birth</th>
				<th>Country</th>
				<th>Actions</th>			
			</tr>";
		for($i=0;$i<$num_rows;$i++)
		{
			$user = mysqli_fetch_assoc($result); //one row 
			$user_id = $user['id'];	

			echo "<tr>";
				echo "<td>".($i+1)."</td>";
				echo "<td>
				       <img src='".$user['profile']."' 
				             width='45px' height='45px'>
				      </td>";
				echo "<td>".$user['firstname']."</td>";
				echo "<td>".$user['surname']."</td>";
				echo "<td>".$user['email']."</td>";
				echo "<td>".$user['phone']."</td>";
                echo "<td>".$user['dateofbirth']."</td>";
				echo "<td>".$user['country']."</td>";
				echo "<td ><a href='editUser.php?id=$user_id' class='edit-btn'><i class='fas fa-edit'></i></a>
				          <a href='#' onclick='confirmDelete(".$user_id.")' class='delete-btn'><i class='fas fa-trash'></i></a>
				      </td>";

			echo "</tr>";
		} //end for
		echo "</thead>";
		echo "</table>";
		} //admin role
		else{
			echo "<script>
					alert('Adminstrator only!');
				</script>";
		}
	}//isset
	else {
		echo "<script>
				alert('Please login at first! Administrator only!');
				 window.location.href='home.php';
			</script>";
	}

	?>
</div>
	<script type="text/javascript">

	function confirmDelete(user_id){
		if(confirm("Are you sure you want to delete?"))
		{
			window.location.href="deleteUser.php?id="+user_id;
		}else{
			document.getElementById('mydiv').innerHTML="<b><i>Cancel to delete user!</i></b>";
		}
	}
	</script>
	 <footer>
        <?php 
            
            include 'footer.php'; 
        
        ?>

            <script type="text/javascript">
                document.getElementById('you_are_here').innerHTML="<b>User List Page</b>";
            </script>
    </footer>
</body>
</html>